function [N0,CN]=lor_rot(N0_init, x0, F0,dR,rotnum)

%input : N0_init, x0,  F0,dR, rotnum

% N0_init:  1D array, size 3*nd by 1 , normalized 
% x0:       1D array, size 3*nd by 1 
% F0:  graident force at x0:   size 3*nd by 1 
% dR : dimer length 
% rotnum :  current iter # in this rotation 


%output: N0, CN
% N0:   (normalized) min-mode,   1D array, size 3*nd by 1 
% CN:   curvature, (smallest eigenvalue), =lambda= (N0,Hess*N0)

% external subroutine: 'force.m', 'newthree.m'


%%will be used and saved during different calls 
%only  exclusively used for this subroutine
global Ax % same size of x0
global Ap % same size of x0
global FN % same size of x0
global mypp %same size of x0

% for force.m
global xx % size (np, 3) see main file for definition 
% temp used to save reallocation and calcualte force 
% the frozen atoms in 'xx' MUST NOT change !




tt=zeros(3,1);

FNu=FN/norm(FN);


xx(1:175,1)=x0(1:175)+dR*FNu(1:175);
xx(1:175,2)=x0(176:350)+dR*FNu(176:350);
xx(1:175,3)=x0(351:525)+dR*FNu(351:525);
Aw=-(force(xx)-F0)/dR; % not global, just temp use in this subroutine
 

AA(1,1)=Aw'*FNu;
AA(1,2)=Aw'*N0_init;
AA(2,1)=AA(1,2);
AA(2,2)=Ax'*N0_init;

 

 

if (rotnum>1)  % 3*3 matrice definition for second call.
    AA(3,3)=mypp'*Ap;
    AA(1,3)=mypp'*Aw;
    AA(3,1)=AA(1,3);
    AA(2,3)=N0_init'*Ap;
    AA(3,2)=AA(2,3);
    BB=eye(3);
    BB(1,3)=mypp'*FNu;
    BB(3,1)=BB(1,3);
    BB(2,3)=mypp'*N0_init;
    BB(3,2)=BB(2,3);


end


if (rotnum==1)

    b=AA(1,1)-AA(2,2);
    tt(1)=AA(1,2);
    if (b>0.0)
        tt(2)=(-b-sqrt(b*b+4.0*tt(1)*tt(1)))/2.0;
    else
        tt(2)=(2.0*tt(1)*tt(1))/(b-sqrt(b*b+4.0*tt(1)*tt(1)));
    end
    tt=tt/sqrt(tt(1)*tt(1)+tt(2)*tt(2));

    N0=tt(1)*FNu+tt(2)*N0_init;
    CN=tt(1:2)'*AA*tt(1:2);
    Ax=tt(1)*Aw+tt(2)*Ax;
    FN=Ax-N0*(N0'*Ax);
    Ap=Aw;
    mypp=FNu;

else    
    
    % B?s cholesky.
    
% WARNING : SOMETIMES chol gives errors. 
%           future code should handle this error msg

    L=chol(BB,'lower');
    L=inv(L);
    AA=L*AA*L';
  
  
    
    [CN,tt]=newthree(AA);
     
    tt=L'*tt;
    N0=tt(1)*FNu+tt(2)*N0_init+tt(3)*mypp;
    Ax=tt(1)*Aw+tt(2)*Ax+tt(3)*Ap;
    FN=Ax-N0*(N0'*Ax);
    mypp=tt(1)*FNu+tt(3)*mypp;
    myppu=norm(mypp);
    mypp=mypp/myppu;
    Ap=(tt(1)*Aw+tt(3)*Ap)/myppu;

    
end


