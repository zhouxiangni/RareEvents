function[f,v]=force(xx)


np=343;
nd=175;

% np = total of atoms 
% nd = 175 = # of free atoms

% input : xx , array size (np,3)
% Output: f , array size(3*nd,1)

 

%     double precision (a-h,o-z);
% C


global Fcall

Fcall=Fcall+1;


iflag=2;

 
 
% C
%  double precision x(nd,3),f(nd,3)
% double precision xx(np,3)
f=zeros(nd,3);
% C
% C Input: position x
% C        iflag=1: potential energy only
% C        iflag=2: force only
% C        iflag=3: energy + force
% C Output: force f, potential energy v
% C
%       common /config/xx
%       common /feval/numf

%  numf=numf+1;
% C
aa=0.7102d0;
a=1.6047d0;
r0=2.8970d0;
%C
rc=9.5d0;
rc2=rc*rc;
%C
e=exp(-a*(rc-r0));  %??? dexp?
e2=e*e;
ecut=e2-2.d0*e;
%C
c=2.74412d0;
box1=7.d0*c;
box2=4.d0*sqrt(3.d0)*c;
%C
%C
%C
v=0.d0;
% C
% C atoms below zfix are fixed
% C      zfix=6.7212d0
% C
for i=1 : nd
    for j=i+1 : np
        %C minimum distance between i and j
        rx=xx(i,1)-xx(j,1);
        %           rx=rx-box1*dnint(rx/box1);
        rx=rx-box1*round(rx/box1);
        ry=xx(i,2)-xx(j,2);
        ry=ry-box2*round(ry/box2);
        rz=xx(i,3)-xx(j,3);
        % C
        r2=rx*rx+ry*ry+rz*rz;
        %         if(r2>rc2) goto 100
        if (r2>rc2)
            continue
        end
        % C
        r=sqrt(r2);
        e=exp(-a*(r-r0));
        e2=e*e;
        % C
        % C potential energy
        if(iflag==1 || iflag==3)
            v=v+(e2-2.d0*e) - ecut;
        end
        % C
        % C force
        if(iflag==2 || iflag==3)
            ff=(e2-e)/r;
            dfx=ff*rx;
            dfy=ff*ry;
            dfz=ff*rz;
            f(i,1)=f(i,1)+dfx;
            f(i,2)=f(i,2)+dfy;
            f(i,3)=f(i,3)+dfz;
            % C
            if(j<=nd)
                f(j,1)=f(j,1)-dfx;
                f(j,2)=f(j,2)-dfy;
                f(j,3)=f(j,3)-dfz;
            end
        end
        %C
        %           100    continue
    end
end
%C
v=v*aa;
%C
tmp=2.d0*a*aa;
for i=1:nd
    for j=1:3
        f(i,j)=f(i,j)*tmp;
    end
end
 

 f=reshape(f,nd*3,1);
%C
%   return
