clear all

% external subroutines:
% force.m
% lor_rot.m  <-- newthree.m

global Fcall % shared by 'force.m'

global xx 
% xx contains all atoms : 
%  global is used to pass frozen atoms
% ONLY for calculating gradient 'force.m' by taking new info from 'x0'



%------------------------------------------
%only for communication with 'lor_rot.m'
%%will be used and saved during different calls 
%only  exclusively used for this subroutine
global Ax % same size of x0
global Ap % same size of x0
global FN % same size of x0
global mypp %same size of x0
%only for communication with 'lor_rot.m'
%------------------------------------------



 
%minimum (total atoms = 56*6 + 7 = 343)
%size : 343 * 3
XX_min = load('XX_min1.txt');%%%% load XXmin123456....

%saddle (total atoms = 56*6 + 7 = 343)
%size : 343 * 3
XX_sp= load('XX_sp1.txt');


nd=175;  % # of free atoms
np=343;  % # of total atoms. The first 'nd' atoms are free 


if (size(XX_min) ~= size(XX_sp) ) | ( size(XX_min,1) ~= np ) 
    error('XX_min/XX_sp has wrong size');
end 

%DO NOT CHANGE: XX_min  XX_sp , nd np 


%------VARIABLES---------
 
%x0 : 1D array for free atoms (updated at each iteration) 
%N0 : 1D array for min-mode  
x0=zeros(nd*3,1); 
N0=zeros(3*nd,1);
F0 = zeros(3*nd,1);


%xx contains all atoms : 
% ONLY for calculating gradient 'force.m' by taking new info from 'x0'
xx= zeros(np,3);


Feff     = zeros(3*nd,1);
Feff_fwd = zeros(3*nd,1);
F_fwd    = zeros(3*nd,1);
F_bkd = zeros(3*nd,1);
Fold     = zeros(3*nd,1);
Fxtem      = zeros(3*nd,1);
g        = zeros(3*nd,1);



%----initialization------
N0 = XX_sp(1:nd,:) - XX_min(1:nd,:);
N0 = N0/norm(N0,'fro'); 
 
xx(1:nd,:) = XX_min(1:nd,:)+0.5*N0; % initial configuration of free atoms

%-----  MUST NOT CHANGE FROZEN ATOMS-------
xx(nd+1:np,:) = XX_min(nd+1:np,:); %fixed configuration of frozen atoms
%-----  -------

%working on 1D array 
x0(1:nd*3)= reshape(xx(1:nd,1:3), 3*nd,1) ;
%x0: transform into array form for initial 
N0=reshape(N0,3*nd,1); % dimer direction 



% tol and other parameters
Ftol=1e-9;  % tol for terminating saddle seaerch  
dR=1e-10;   % dimer length, used for finite difference 

rotmax= 7;   % Max Iter # withing rotation 
FNmin=0.001;FNmax=0.001;  % tol for rotation 

iflag=2; % for 'force.m'



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

IMF_FLAG = false ;  
% true = use inner loop; 
% false = 1 single inner loop, see 'Max_Iner' variable 

Init_CG_FLAG = false ;
% true:  CG for initial search step in subproblem
% false:  GAD for initial search step in subproblem
Inner_CG_FLAG = false;
% true:  CG from second search step in subproblem
% false:  steepest descent for L from second    search step in subproblem
%************ some numerical experience in using ************
%  It is essential to  turn 'ON' Inner_CG_FLAG when using  IMF_FLAG = true
%  Init_CG_FLAG 'on off' does not matter.  Usually Init_CG_FLAG 'off' is prefered.

% When IMF_FLAG = 'off' (traditional rot-translation method like dimer's method),
%    then Init_CG_FLAG should  turn 'ON' for better performance
%       (Inner_CG_FLAG does not function when IMF_FLAG = 'off')
%     When Init_CG_FLAG is 'off', then step_flag = 24 is better than step_flag =1 ;     



step_flag = 1 ; % select methods of step_size = 1, 14 or 24


MAX_CYCLE =  120 ;

MAG_REV_FORCE = 2.0;  % project force:   (I - MAG * n \otimes n )
if (step_flag == 24)
    MAG_REV_FORCE = 3.0;  % suggested value 
end 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



outp = fopen('out.txt','w+');
outp2= fopen('xpoint.txt','a');

 

% ---only for recording use to benchmark algorithm efficiency 
% zrot(ic) :  rotnum used in rotation step during CYCLE 'ic'

t=0;  % track all iterations, inner and outer 
%F_err_record_all(t);  |\nabla V| for all x and y, after 't', tracking  together with 'Force_call_all' 
%Force_call_all(t): 


Fcall=0;  % total number of force call, global variable, counted in 'force.m'; 
Fcall2=0; % # of force call for subproblem/translation, manuall counted. 
%Force_call2(ic) % total # of force calls spent for subproblem min_L after CYCLE 'ic'
%Force_call(ic) % total # of force calls  after CYCLE 'ic'
%F0_err_record(ic)=norm(F0); % norm of force for x after CYCLE 'ic'
%x_record(:,ic)= x0; %   'x' after CYCLE 'ic'
% -------------------


%initial force 
F0=force(xx);  Fcall2 = Fcall2+1;
init_F0 = norm(F0); 


%main IMF loop 'CYCLE'
for ic =1 : MAX_CYCLE

    %------------------------------------------ 
    %***** rotation step ****
    %------------------------------------------- 

    %......these only for initialization of  rot .........
    % x + delta x for finite differencing 
    xx(1:nd,1)=x0(1:nd)         +dR*N0(1:nd);
    xx(1:nd,2)=x0(nd+1:2*nd)    +dR*N0(nd+1:2*nd);
    xx(1:nd,3)=x0(2*nd+1:3*nd)  +dR*N0(2*nd+1:3*nd);
    Ax=(F0 - force(xx) )/dR; % approximation to Hess*N0
    %FN=(eye(3*nd)-N0*N0')*(-Ax); % projection  
    FN = -Ax + N0 .* dot(N0,Ax);
    CN=dot(N0,Ax); % (N0,Hess*N0)  
    
    %%%%%%%rot : input N0, output N0
    for rotnum=1 : rotmax
        if (norm(FN)<FNmin)
             fprintf(outp,'FNr min converged,rotnum=%d\n',rotnum);
             zrot(ic)=rotnum-1;
            break;
        else
            [N0,CN] = lor_rot(N0,x0,F0,dR,rotnum);  
            % KEY SUBROUTINE to call for rotation             
            % lor_rot is not a clean subroutine, using global variables

            if (norm(FN)<FNmax)
                fprintf(outp,'FNr max converged,rotnum=%d\n',rotnum);
                zrot(ic)=rotnum;
                break;
            end
        end
        if (rotnum==rotmax)
            disp(['ic='  num2str(ic)   ' rotmax=' num2str(rotmax)  ' (ignore this) ']);
            zrot(ic)=rotnum;
        end 
    end
    % end of rotation 

    % ------------
    % N0 is the min-mode corresponding to F0
    % CN = lambda(x0) = (N0, Hess*N0)
    % ------------

    %------------------------------------------ 
    %***** translation or subproblem solver ****
    %------------------------------------------- 
    
    if (IMF_FLAG == false )  % classic rotation-translation pair
        Max_Iner = 1 ;
    else                     % IMF idea: using inner iteration for subproblem
        if (norm(F0)>0.1) % recommended parameter
            Max_Iner=5;
        else
            Max_Iner=50;
        end
    end  
    
    F0N0 = dot(F0,N0); %temp variable for common use in following 'inner_i' loop
    CONVERGED = false; % pass out info if 'y' satifies Ftol during subproblem solving
    for inner_i=1:Max_Iner 
     %%%  N0, X0, F0, CN, are fixed 
     %%%  update 'xtem' ( y variable in IMF)
     %%%  'Feff' is negative gradient function of objective function L 
     %%%  'MAG_REV_FORCE' (>1) is alpha+beta in IMF, default value =2 in GAD 

        if inner_i==1 
            % GAD force = initial search direction = gradient of L(y,x0) at y=x0 
            Feff = F0- N0 .*(F0N0) * MAG_REV_FORCE;
            
            if ( Init_CG_FLAG == true )
            %search direction (CG type, dimer's method style)
                %'Fold' is the  - gradient of L(y,x0) from last iteration in previous CYCLE 'ic-1' 
                a1 = abs(Feff'*Fold);   a2 = Fold'*Fold;
                if ((a1 <= 0.5*a2) && (a2 ~= 0.0))
                    gam = Feff'*Feff/(a2);
                else
                    gam = 0.0;
                end
                g = Feff+g*gam;
            else % if want to always use GAD as initila direction 
                g = Feff; 
            end 
            norm_g = norm(g);
            g_unit = g/norm_g; %normalized seaerch direction  

            Fold =  Feff;

            %force at forward to calculate lambda, or curvature 
            xx(1:nd,1) = x0(1:nd)        +dR*g_unit(1:nd);
            xx(1:nd,2) = x0(nd+1:2*nd)   +dR*g_unit(nd+1:2*nd);
            xx(1:nd,3) = x0(2*nd+1:3*nd) +dR*g_unit(2*nd+1:3*nd);  
            F_fwd = force(xx);         Fcall2=Fcall2+1;
            Feff_fwd = F_fwd - MAG_REV_FORCE * dot(F_fwd,N0) .* N0;
            
            curvature = dot(g_unit, (Feff - Feff_fwd)./dR); 
            %  =  (g_unit,  Hess of L  * g_unit);
            % This is the curvature for new obj function L(y;x0) along search direction 
            % only positive value makes sense of minimizing L(y;x0) along 'g_unit'

            %calculation of step size  
            if (curvature <= 0.0) %   
                step_size = 0.1;
            else
                if (step_flag == 1 )%  stepsize in the original IMA paper
                    step_size = dot(g_unit, 0.5*(Feff+Feff_fwd)) ...
                                            / curvature;
                elseif ( step_flag == 14 | step_flag == 24 )
                    %Amit's draft
                    % need third derivative of potential : q  
                    % derivative of  Feff(x+ a* g_unit) w.r.t 'a'=0;
                    % force at backward 
                    xx(1:nd,1) =x0(1:nd)        -dR*g_unit(1:nd);
                    xx(1:nd,2) =x0(nd+1:2*nd)   -dR*g_unit(nd+1:2*nd);
                    xx(1:nd, 3)=x0(2*nd+1:3*nd) -dR*g_unit(2*nd+1:3*nd);     
                    F_bkd=force(xx);          Fcall2=Fcall2+1;
 
                    % F0  save -\nabla V at 'x0'  ( y_0 in IMF)  
                    Hm = - (F_fwd-F_bkd)/2.0/dR; %central differencing for Hess*g_unit  
                    mPHm =  dot(g_unit,  Hm - MAG_REV_FORCE*dot(Hm,N0) .*N0 );  
                    gHM = dot(-F0, Hm);
                    HmHm = dot(Hm,Hm);
                     
                    pm =  dot (g_unit, Feff);  
                    % dot of 'm' (search direction) and GAD force '(I- MAG* N0*N0')* (-\nabla V(x0)) '

                    q = - ( F_fwd + F_bkd - 2.0*F0 )./dR./dR;  
                    %second derivative of \nabla V(x+t*g_unit) at t =0;
                    qm = dot(q, g_unit); 
                    gq = dot(-F0,q);  

                    if (step_flag == 14 ) %Amit's Equation 14
                        if (qm*pm <0)  
                            error('qm*pm is negagive. SQRT fails!')
                        else
                            step_size = pm /(mPHm + sqrt(norm_g*qm));
                        end
                    elseif (step_flag == 24 ) %Amit's Equation 24
                        if ( abs(gq / (HmHm-gq))  < 0.02 )  
                                step_size = abs(  gHM ./ (HmHm - gq)  );
                        else
                                step_size = abs(  gHM ./ HmHm  );
                        end  
                    end
                else 
                    error('wrong step_flag');

                     %end if for Amit's  two choices of step size  
                end  % end if of set up all step_size formula                                   
            end % end of set up step_size 
            %avoid overshoot by imposing MAX_STEP_SIZE
            MAX_STEP_SIZE = 0.1;
            step_size = min(abs(step_size), MAX_STEP_SIZE) * sign(step_size);

            
            %update position of y : y0=x0 -> y_1
            xtem = x0 + g_unit*step_size; 
            
            t = t+1 ;
            Force_call_all(t) = Fcall; 
           

        else % inner_i > 1 
            
            xx(1:nd,1:3)=reshape(xtem(1:3*nd),nd,3);
            Fxtem = force(xx) ; Fcall2=Fcall2+1; 

            % record error at the end of previous 't'
            F_err_record_all(t) = norm(Fxtem);


            if (norm(Fxtem)< Ftol)  %global stopping rule
                fprintf(outp2,'sp %d\n',reshape(xx,np,3));
                disp(['Saddle Found at ic = ', num2str(ic),  ... 
                      ' after inner_i=', num2str(inner_i-1) ] );
                CONVERGED = true ; 
                break; 
                %   'xterm' at (inner_i-1) already converged,
            end
             
            % Feff:= - gradient of L(y;x0)'s quadratic approximation
            %   this is NOT GAD force
            Feff = Fxtem - MAG_REV_FORCE .*N0 .* (F0N0)  ...
                     + MAG_REV_FORCE*CN .*N0 .* dot(N0,(xtem-x0));
            % INEXACT STOPPING RULE  
            if  norm(Feff)<min(0.01,max(0.1*(norm(F0))^1.3,1e-10))
                disp(['subproblem  converged at inner_i=', num2str(inner_i)]);
                break; % exit the current loop 
            end

            % Conjugate Gradient as search direction 
            % copied from dimer method's source code
            % a modified  Fletcher and Reeves nonlineaer CG
            % 'a1' is related to Polyak and Ribiere
            % 'Fold' = gradient of objective function at previous step
            %............. any other CG can be used here .....e.g. ref.
            %  'A survey of nonlinear conjugate gradient methods'
            %  by William W Hager, Hongchao Zhang
            % Pacific journal of Optimization, Vol. 2, No. 1. (2006), pp. 35-58
            %........................
            if ( Inner_CG_FLAG == true  )
                a1 = abs(Feff'*Fold);  a2 = Fold'*Fold;
                if ((a1 <= 0.5*a2) && (a2 ~= 0.0))
                    gam = Feff'*Feff/(a2);
                else
                    gam = 0.0;
                end
                %search direction 
                g=Feff+g*gam;
            else 
                g = Feff;
            end
            norm_g = norm(g); g_unit=g/norm_g;

            Fold=Feff;

            %force at forward 
            xx(1:nd,1)=xtem(1:nd)       +dR*g_unit(1:nd);
            xx(1:nd,2)=xtem(nd+1:2*nd)  +dR*g_unit(nd+1:2*nd);
            xx(1:nd,3)=xtem(2*nd+1:3*nd)+dR*g_unit(2*nd+1:3*nd);
            F_fwd=force(xx);            Fcall2=Fcall2+1;

            Feff_fwd = F_fwd -  MAG_REV_FORCE .*N0 .*(F0N0) ...
                    + MAG_REV_FORCE*CN .*N0.* dot(N0,xtem+dR*g_unit-x0);

             
            curvature =  dot(g_unit, (Feff-Feff_fwd)./dR ); 
            %  =  (g_unit,  Hess of L  * g_unit);
            % This is the curvature for new obj function L(y;x0) along search direction 
            % only positive value makes sense of minimizing L(y;x0) along 'g_unit'
            %calculation of step size  

            if (curvature <0.0)
                step_size = 0.1;
            else
                if  (step_flag == 1 )% IMA paper
                    step_size = dot(g_unit, 0.5*(Feff+Feff_fwd)) ...
                                            / curvature;
                elseif ( step_flag == 14 | step_flag == 24 )
                    %Amit's draft
                    % need third derivative of potential : q  
                    % derivative of  Feff(x+ a* g_unit) w.r.t 'a'=0;
                    % force at backward 
                    xx(1:nd,1) =x0(1:nd)        -dR*g_unit(1:nd);
                    xx(1:nd,2) =x0(nd+1:2*nd)   -dR*g_unit(nd+1:2*nd);
                    xx(1:nd, 3)=x0(2*nd+1:3*nd) -dR*g_unit(2*nd+1:3*nd);     
                    F_bkd=force(xx);          Fcall2=Fcall2+1;
 
                    % Fxtem  save -\nabla V at 'xtem'  ( y_i in IMF)  
                    Hm = - (F_fwd-F_bkd)/2.0/dR; %central differencing for Hess*g_unit  
                    mPHm =  dot(g_unit,  Hm - MAG_REV_FORCE*dot(Hm,N0) .*N0 );  
                    gHM = dot(-Fxtem, Hm) ;
                    HmHm = dot(Hm,Hm) ;


                    pm =  dot (g_unit, Fxtem - MAG_REV_FORCE * dot(Fxtem,N0) .* N0 );  
                    % dot of 'm' (search direction) and projected gradient '(I- MAG* N0*N0')* (-\nabla V(xtem)) '

                    q = - ( F_fwd + F_bkd - 2.0*Fxtem )./dR./dR;  
                    %second derivative of \nabla V(x+t*g_unit) at t =0;
                    qm = dot(q, g_unit); 
                    gq = dot(-Fxtem,q);  

                    if (step_flag == 14 ) %Amit's Equation 14
                        if (qm*pm <0)  
                            error('qm*pm is negagive. SQRT fails!')
                        else
                            step_size = pm /(mPHm + sqrt(pm*qm) );
                        end
                    elseif (step_flag == 24 ) %Amit's Equation 24
                        if ( abs(gq / (HmHm-gq))  < 0.02 )  
                            step_size = abs(  gHM ./ (HmHm - gq)  );
                        else
                            step_size = abs(  gHM ./ HmHm  );
                        end  
                    end %end if for Amit's step size  
                else 
                    error('wrong step_flag');
                end % end if of set up all step_size formula                                   
            end % end of set up step_size 
            %avoid overshoot by imposing MAX_STEP_SIZE
            MAX_STEP_SIZE = 0.1;
            step_size = min(abs(step_size), MAX_STEP_SIZE) * sign(step_size);

            %update position of y_i -> y_{i+1} 
            xtem = xtem + g_unit*step_size;

            t = t + 1 ;
            Force_call_all(t) = Fcall; 

            if ( inner_i == Max_Iner )
                disp('Max_Iner is reached for subproblem ! ' );
            end 
             
        end % end of if inner_i ==1 else >1  
         
        
    end  % end of for inner_i = 1 : ...

    % One CYCLE finished
    
    
 
    %update X0 and F0
    x0=xtem;

    %-record 
    x_record(:,ic)= x0;        
    Force_call2(ic)= Fcall2;
    Force_call(ic) = Fcall;

    if (CONVERGED == true)
        % force aleady was calcuated in Feff 
        F0_err_record(ic) = norm(Feff);
        break; %exit  for 'ic' loop
    end   

    %for next CYCLE and convergence test 
    xx(1:nd,1:3)=reshape(x0(1:3*nd),nd,3);
    F0 = force(xx);  Fcall2 = Fcall2 + 1 ;

    F0_err_record(ic) = norm(F0);
    F_err_record_all(t) = norm(F0);
    
    % convergence test     
    % calculate force acted on free atoms: need ALL atoms configuration 
    if  (max(abs(F0))<Ftol )  %L_inf norm
        disp(['Saddle Found after ic = ', num2str(ic)] );
        max(abs(F0))
        fprintf(outp,'all convegered');
        fprintf(outp2,'all convegered');
        fprintf(outp2,'sp %d\n', xx);
        break
    end


    if (ic == MAX_CYCLE)
        disp(['ic=MAX_CYCLE=' num2str(MAX_CYCLE)  ...
                ' reached. BUT Ftol is not reached']);
    end 

end % end of ALL IMF LOOP i = 1:...

  
figure(1); 
xlabel(' # of force calculation '); 
ylabel('$\nabla V$')'';
semilogy([0 Force_call(1:ic)],  ...
        [init_F0 F0_err_record(1:ic)],'-s');
hold on ; 
if (IMF_FLAG == true)
    semilogy([0 Force_call_all(1:t)], ...
            [init_F0 F_err_record_all(1:t)],':');
end 


figure(2); 
xlabel('Iter '); ylabel('$\nabla V$')'';
semilogy([0:ic],[init_F0 F0_err_record(1:ic)],'-or');
hold on ; 
