% rotation step in dimer code

function [N0]=rot_dimer()

global F0
global xx
global FN
global FNold
global GN
global GNu
global N0
global N
global nd
global dR
global x0
a1=abs(FN'*FNold);
a2=norm(FNold);
a2=a2*a2;
if ((a1<=0.5*a2) && (a2~=0.0))
    GamN = (FN'*(FN-FNold))/a2;
else
    GamN = 0.0;
end
GN = FN+GN*GamN;
GN = GN-(GN'*N0)*N0;  %%�����ֽ�
GNu = GN/norm(GN);
FN1 = FN'*GNu;
% CALL Rotate(N,GNu,PI/4._q)
%     SUBROUTINE Rotate(V1,V2,tTh)
%       REAL(q),DIMENSION(3,Nions) :: V1,V2,V1tmp
%       REAL(q) :: tTh,cTh,sTh
%       cTh = COS(tTh)
%       sTh = SIN(tTh)
%       V1tmp = V1
%       V1 = V1*cth+V2*sTh
%       V2 = V2*cth-V1tmp*sTh
%     END SUBROUTINE Rotate
cth=cos(pi/4.0);sth=sin(pi/4.0);
V1tmp = N0;
N0 = N0*cth+GNu*sth;
GNu= GNu*cth-V1tmp*sth;
N0=N0/norm(N0);
GNu=GNu/norm(GNu);
%xx(1:3*nd,1)=x0+dR*N0;
 xx(1:175)=x0(1:175)+dR*N0(1:175);
 xx(344:518)=x0(176:350)+dR*N0(176:350);
 xx(687:861)=x0(351:525)+dR*N0(351:525);
F2=force(xx);
FNN=(eye(3*nd)-N0*N0')*(F2-F0)/dR;
FN2=FNN'*GNu;
if (FN2~=0.0) 
Th = atan(FN1/FN2)/(-2.0);
else
Th = pi/(-2.0);
end
if (FN2>0.0) 
 Th = Th+pi/2.0;
end
cth=cos(Th-pi/4.0);sth=sin(Th-pi/4.0);
V1tmp = N0;
N0 = N0*cth+GNu*sth;
GNu= GNu*cth-V1tmp*sth;
GN=GNu*norm(GN);
N0=N0/norm(N0);
