
%subroutined only used for LOR algorithm 

function [lam,x]=newthree(A3)

% A3: 3*3 matrix
% lam, x :  minimal eigenvalue and its eigenvector 


m = trace(A3)/3;
B3 = A3-m*eye(3);
q = det(B3)/2; 
p = 0;
x=zeros(3,1);
for i=1:3
    for j=1:3
        p = p + B3(i,j)^2;
    end
end
p = p/6;
 
phi = 1/3*acos(q/p^(3/2));
 
% NOTE: the follow formula assume accurate computation and therefore
% q/p^(3/2) should be in range of [1,-1], but in real code, because
% of numerical errors, it must be checked. Thus, in case abs(q) >=
% abs(p^(3/2)), set phi = 0;
if(abs(q) >= abs(p^(3/2)))
    phi = 0;
end
 
if(phi<0)
    phi=phi+pi/3;
end
 
eig1 = m + 2*sqrt(p)*cos(phi);
eig2 = m - sqrt(p)*(cos(phi) + sqrt(3)*sin(phi));
eig3 = m - sqrt(p)*(cos(phi) - sqrt(3)*sin(phi));
lam=min([eig1,eig2,eig3]);
    B=A3-lam*eye(3);
    S2=(B(1,1)*B(2,2)-B(2,1)*B(1,2))^2+(B(1,1)*B(3,2)-B(3,1)*B(1,2))^2+(B(2,1)*B(3,2)-B(3,1)*B(2,2))^2;
    S3=(B(1,1)*B(2,3)-B(2,1)*B(1,3))^2+(B(1,1)*B(3,3)-B(3,1)*B(1,3))^2+(B(2,1)*B(3,3)-B(3,1)*B(2,3))^2;
%   rou=zeros(3);
%     for i=1:3
%      for j=1:3
%         rou(i,j)=B(i.1)*B(j,1)+B(i,2)*B(j,2)+B(i,3)*B(j,3);
%      end
%     end
    if S2>=S3  %(1,2�����޹�)
        x(3)=1;
        x(1)=-(B(1,3)*B(2,2)-B(1,2)*B(2,3))/(B(1,1)*B(2,2)-B(1,2)*B(2,1));
        x(2)=-(B(1,1)*B(2,3)-B(1,3)*B(2,1))/(B(1,1)*B(2,2)-B(1,2)*B(2,1));
    else
        x(2)=1;
        x(1)=(B(1,3)*B(2,2)-B(1,2)*B(2,3))/(B(1,1)*B(2,3)-B(1,3)*B(2,1));
        x(3)=-(B(1,1)*B(2,2)-B(1,2)*B(2,1))/(B(1,1)*B(2,3)-B(1,3)*B(2,1));
    end
    x=x/norm(x);
